package connectFour;

import java.util.Random;
import java.io.*;

public class BotPlayer{
  private Random random;
  private Chip chip;
  private String name;



  public BotPlayer(Chip chip, String name){
    this.chip = chip;
    this.name = name;
    random = new Random();
  }


  public int getColumn(){
    int userInput = random.nextInt(3);

    return userInput;
  }

}