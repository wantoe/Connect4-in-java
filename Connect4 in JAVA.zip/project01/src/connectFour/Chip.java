package connectFour;


public class Chip{
  private char c;

  public Chip(char c){
    this.c = c;
  }

  public char getChip(){
    return c;
  }
}