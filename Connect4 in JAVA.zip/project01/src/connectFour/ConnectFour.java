package connectFour;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Random;

// CLASS
public class ConnectFour {

  //INSTANCE FIELD
	private BufferedReader input; // READ INPUT	declaration
	private char[][] board; // BOARD ARRAY declaration
  
  // Constructor method
	public void MyConnectFour(){
		board = new char[6][7]; // BOARD LAYOUT
		input = new BufferedReader(new InputStreamReader(System.in)); // READ INPUT from terminal
    printBoard(); //print board
		playGameRedStart(); // calling playGame function
	}

	// This METHOD consists the whole game flow logic when human is starting the game
	private void playGameRedStart(){
    Random rand = new Random();
		boolean win = false;
		while(!win){
      
			// player 1 - human - red token
      char redToken = 'r';
      // String userInput = getUserInput(); // collect column no. from user
      int move = getUserInput(redToken);
			placeCounter(redToken,move); // This place red counter into the board

      // check if Red player has won
      boolean hasWon = false;
      hasWon = fourConnectCheck(redToken, hasWon);
      printBoard(); //print updated board 
      //if human win, then end program, otherwise bot player's turn
			if(hasWon){
				win = true;
        System.out.println("You Have Won!!!");
        System.exit(0); // End program.
			}
			else{
				//player 2 - BOT - yellow token
        char yellowToken = 'y';
				// move = getUserInput(yellowToken);
        // generate random number using java.util.Random
        int randomColumn = 1+ rand.nextInt(6); 
        move = randomColumn; System.out.println("\n" + "bot placed yellow token in column "+randomColumn+ "." + "\n");
				placeCounter(yellowToken,move); // place yellow counter
				hasWon = false;
        hasWon = fourConnectCheck(yellowToken, hasWon);
				printBoard(); //print updated board 
        // if BOT wins, end program
				if(hasWon){
					win = true;
          System.out.println("BOT Has Won!!!");
          System.exit(0); // End program.
				}
			}
		}
	}


  // METHOD playGame Yellow Starting
	private void playGameYellowStart(){
    Random rand = new Random();
		boolean win = false;
		while(!win){
			// player 2 - bot - yellow token
      char yellowToken = 'y';
 // collect column no. from user
      // int move = getUserInput(yellowToken);
      int randomColumn = 1+ rand.nextInt(6);
      // generate random number using java.util.Random
      int move = randomColumn; System.out.println("\n" + "bot placed yellow token in column "+randomColumn+ "." + "\n");
			placeCounter(yellowToken,move); // insert user input into this function

      
      // check if BOT  player has won
      boolean hasWon = false;
      hasWon = fourConnectCheck(yellowToken, hasWon);

      printBoard(); //print updated board 
      // check if BOT has won, if so end program. Otherwise human player turn
			if(hasWon){
				win = true;
        System.out.println("BOT Has Won!!!");
        System.exit(0); // End program.
			}
			else{
				//player 1 - human - red token
        char redToken = 'r';
        move = getUserInput(redToken);
				placeCounter(redToken,move);
				hasWon = false;
        hasWon = fourConnectCheck(redToken, hasWon);
				printBoard(); //print updated board 
        // if human wins, end program, otherwise bot's turn
				if(hasWon){
					win = true;
          System.out.println("You Have Won!!!");
          System.exit(0); // End program.
				}
			}
		}
	}


// This method Prints Board
	private void printBoard(){
    // this for loop prints row
		for(int i=0; i<board.length; i++){ 
      // this for loop prints column
			for(int j=0; j<board[i].length; j++){
				if(board[i][j] == 'r'){
					System.out.print("| r ");
				}
				else if(board[i][j] == 'y'){
					System.out.print("| y ");
				}
				else{
					System.out.print("|   ");
				}
			}
			System.out.println("|");
		}
		System.out.println("  1   2   3   4   5   6   7");
	}


		// get user input from terminal and return int column-number
	private int getUserInput(char colorChip){ 
    int columnNum=0;
    // if human input is 1-7, program runs
		try{			
			String toReturn = input.readLine();
      columnNum = Integer.parseInt(toReturn);
      if (columnNum < 1 || columnNum > 7){
        System.out.println("Please enter column number 1 to 7,");
        return getUserInput(colorChip);
      }
		}
    // if input is not 1-7, get user input again
		catch(Exception e){
			System.out.println("Please enter column number 1 to 7,");
      return getUserInput(colorChip);

    }
		return columnNum;
	}


  // This function placecounter into board
	private void placeCounter(char player, int position){
    // int position is the column no.
    // this check if board is full
    int count = 0;
		for(int i=6; i>=0; i--){
      if (board[0][i] == 'y' || board[0][i] == 'r'){
        count = count + 1;        
      }
      else{
        count = 0;
      } // if the board is full, end program
      if (count >= 7){
        System.out.println("Its a draw as the board is full!");
        System.out.println("End game.");
        System.exit(0); // End program.
      }      
    }
    // this function place red token into board. If the column is full, user is asked to input again
		boolean placed = false;
    if(player == 'r'){
      // board.length = 6
			for(int i=board.length-1; i>=0; i--){
				if(!placed){
          if (board[0][position-1] == 'y' || board[0][position-1] == 'r'){
            System.out.println("RED This column is full, please pick another column.");
            playGameRedStart();
            break;
            
          }
          // if the slot is occupied, token wont be placed
					else if(board[i][position-1] == 'y' || board[i][position-1] == 'r'){
						// skip
					}
					else { // This place red token into empty slot
						board[i][position-1] = 'r';
						placed = true;
					}
				}
			}
		}
		else{ // this function place yellow token into board. If the column is full, user is asked to input again
			for(int i=board.length-1; i>=0; i--){
				if(!placed){

         if (board[0][position-1] == 'y' || board[0][position-1] == 'r'){
            System.out.println("YELLOW This column is full, please pick another column.");
            playGameYellowStart();
            break;
          }
          // if the slot is occupied, token wont be placed
					else if(board[i][position-1] == 'r' || board[i][position-1] == 'y'){
						// skip
					}
					else { // This place red token into empty slot
						board[i][position-1] = 'y';
						placed = true;
					} 
				}
			}
		}
	}

  // This method checks if connect4 winning conidition is achieved vertically, horizontally or diagonally.
  private boolean fourConnectCheck(char colorToken, boolean hasWon){
    int count = 0;
    // check horizontal
    for(int i=0; i<board.length; i++){
      count = 0;
      for(int j=0; j<board[i].length; j++){
        if(board[i][j] == colorToken){
          count = count + 1; 
          if(count > 3){ //when horizontal consecutive of red is 4 or more
            hasWon = true;
          }
        }
        else{
          count = 0; // count returns to 0 if consecutive color has not occured
        }
      }
    }
    //check vertical 
    count = 0;
    // board[0].length = 7 // i = 0123456
    for(int i=0; i<board[0].length; i++){
      count = 0;
      // board.length = 6, j=012345
      for(int j=0; j<board.length; j++){
        if(board[j][i] == colorToken){
          count = count + 1;
          if(count > 3){
            hasWon = true; //when connect4 is achieved
          }
        }
        else{
          count = 0; // count returns to 0 if consecutive color has not occured
        }
      }
    }

    //check diagonally downwards from 2;0 to 0;0
    count = 0;
    for (int n=0; n<3; n++){
      count = 0;
      for (int i=0; i<4+n; i++){
        if(board[2-n+i][0+i] == colorToken){
          count = count + 1; 
          if(count > 3){
            hasWon = true; //when connect4 is achieved
          }
        }
        else{
          count = 0; // count returns to 0 if consecutive color has not occured
        }        
      }
    }
    //check diagonally downwards from 0;1 to 0;4
    count = 0;
    for (int n=0; n<3; n++){
      count = 0;
      for (int i=0; i<6-n; i++){
        if(board[0+i][1+i+n] == colorToken){
          count = count + 1;
          if(count > 3){
            hasWon = true; //when connect4 is achieved
          }
        }
        else{
          count = 0; // count returns to 0 if consecutive color has not occured
        }        
      }     
    }
    //check diagonally upwards from 3;0 to 5;0
    count = 0;
    for (int n=0; n<3; n++){
      count = 0;
      for (int i=0; i<4+n; i++){
        if(board[3-i+n][0+i] == colorToken){
          count = count + 1;
          if(count > 3){
            hasWon = true; //when connect4 is achieved
          }
        }
        else{
          count = 0; // count returns to 0 if consecutive color has not occured
        }        
      }     
    }
    //check diagonally upwards from 5;1 to 5;3
    count = 0;
    for (int n=0; n<3; n++){
      count = 0;
      for (int i=0; i<6-n; i++){
        if(board[5-i][1+i+n] == colorToken){
          count = count + 1;
          if(count > 3){
            hasWon = true; //when connect4 is achieved
          }
        }
        else{
          count = 0; // count returns to 0 if consecutive color has not occured
        }        
      }     
    }
    return hasWon; // returns boolean variable hasWon
  }

}
