package connectFour;

//import java.io.*;

public class HumanPlayer{
  private Chip chip;
  private String name;
  private int columnNum;


  public HumanPlayer(Chip chip, String name){
    this.chip = chip;
    this.name = name;
  }

  public Chip getChip(){
    return chip;
  }

  public String getName(){
    return name;
  }

  public int getColumn(){
    return columnNum;
  }

}