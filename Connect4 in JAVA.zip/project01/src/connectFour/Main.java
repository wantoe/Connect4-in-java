package connectFour;
  // MAIN FUNCTION  
class Main {
	public static void main(String[] args){
    PrintStart p = new PrintStart();
    p.startGamePrinting();
		new ConnectFour().MyConnectFour();
	}
}