package connect4Package;

public class Board{
	  private Token[][] board;

	  // constructor 1
	  public Board(){
	    board = new Token[6][7];
	  }
	// constructor 2
	  public Board(int x, int y){
	    board = new Token[x][y];
	  }

	  //print board
	  public void printBoard(){
	  //board.length = 6
	    for(int i=0; i<board.length; i++){
	      // board[i].length = 7
	      for(int j=0; j<board[i].length; j++){
	        if(board[i][j] == null){
	          System.out.print("|   ");
	        }
	        else if(board[i][j] == new Token('y')){
	          System.out.print("| y ");
	        }
	        else{
	          System.out.print("| " + board[i][j].getToken() + " ");
	        }
	      }
	      System.out.println("|");
	    }
	    System.out.println("  1   2   3   4   5   6   7" + "\n");
	  }

	  // add token
	  public void placeToken(int columnNum, Token c) throws Exception{
	    int count = 1;
	    //board.length = 6
	    while (count <= board.length){
	      //if slot is empty, place token
	      if (board[board.length-count][columnNum-1] == null){
	            board[board.length-count][columnNum-1] = c;   
	            break;     
	          }
	      else{
	        count++;
	      }
	      //column is full
	      if (count > board.length){
	        System.out.println("column is full, please choose another column");
	        throw new Exception("column is full, please choose another column");
	      }
	    }
	  }
	  
	  //check if Connect 4 has occurred
	  public boolean checkWin(String playerName, Token token) {
		  checkDraw();
		  checkHorizontal(playerName, token);
		  checkVertical(playerName, token);
		  checkDiagonal(playerName, token);
		  return false;
	  }
	  
	  // check if these is a draw (full board)
	  public void checkDraw() {
		  int i = 0;
		  int count = 0;
		  while (i < board[0].length) {
			  if (board[0][i] != null) {
				  System.out.println("one full");
				  count+=1;
			  }
			  if (count >= board[0].length) {
				  System.out.println("Its a DRAW");
				  System.out.println("program terminates");
				  System.exit(0);
			  }
			  i++;
		  }
	  }
	  
	  // check if theres horizontal connect4
	  public void checkHorizontal(String playerName, Token token) {
		    int count = 0;
		    
		    // check horizontal
		    for(int i=0; i<board.length; i++){
		      count = 0;
		      for(int j=0; j<board[i].length; j++){
		        if(board[i][j] == token){
		          count = count + 1; 
		          if(count > 3){ //when horizontal consecutive of red is 4 or more
		        	  winAndTerminate(playerName);
		          }
		        }
		        else{
		          count = 0; // count returns to 0 if consecutive color has not occured
		        }
		      }
		    }
	  }
	  
	// check if theres vertical connect4
	  public void checkVertical(String playerName, Token token) {
		    //check vertical 
		    int count = 0;
		    // board[0].length = 7 // i = 0123456
		    for(int i=0; i<board[0].length; i++){
		      count = 0;
		      // board.length = 6, j=012345
		      for(int j=0; j<board.length; j++){
		        if(board[j][i] == token){
		          count = count + 1;
		          if(count > 3){ //when connect4 is achieved
		        	  winAndTerminate(playerName);
		          }
		        }
		      }
		    }
	  }
	  
		// check if theres diagonal connect4
	  public void checkDiagonal(String playerName, Token token) {
		    int count = 0;
		    //check diagonally downwards from 2;0 to 0;0
		    for (int n=0; n<3; n++){
		      count = 0;
		      for (int i=0; i<4+n; i++){
		        if(board[2-n+i][0+i] == token){
		          count = count + 1; 
		          if(count > 3){
		        	  winAndTerminate(playerName);//when connect4 is achieved
		          }
		        }
		      }
		    }
		    //check diagonally downwards from 0;1 to 0;4
		    count = 0;
		    for (int n=0; n<3; n++){
		      count = 0;
		      for (int i=0; i<6-n; i++){
		        if(board[0+i][1+i+n] == token){
		          count = count + 1;
		          if(count > 3){
		        	  winAndTerminate(playerName);//when connect4 is achieved
		          }
		        }
		      }     
		    }
		    //check diagonally upwards from 3;0 to 5;0
		    count = 0;
		    for (int n=0; n<3; n++){
		      count = 0;
		      for (int i=0; i<4+n; i++){
		        if(board[3-i+n][0+i] == token){
		          count = count + 1;
		          if(count > 3){
		        	  winAndTerminate(playerName);//when connect4 is achieved
		          }
		        } 
		      }     
		    }
		    //check diagonally upwards from 5;1 to 5;3
		    count = 0;
		    for (int n=0; n<3; n++){
		      count = 0;
		      for (int i=0; i<6-n; i++){
		        if(board[5-i][1+i+n] == token){
		          count = count + 1;
		          if(count > 3){
		        	  winAndTerminate(playerName);//when connect4 is achieved
		          }
		        }
		      }     
		    }
	  }
	  
	  
	  public void winAndTerminate(String playerName) {
		  System.out.println(playerName + " wins");
		  System.out.println("program terminates");
		  System.exit(0);
	  }
	  
	  
	  
	}
