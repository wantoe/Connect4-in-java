package connect4Package;

import java.util.Random;

public class BotPlayer extends Player{
// field
  private Random random;

// constructor 1
  public BotPlayer(Token token){
    super(token);
    random = new Random();
  }

// constructor2
  public BotPlayer(Token token, String name){
    super(token,name);
    random = new Random();
  }

  public String getMove(){
    int r = 1+ random.nextInt(6);
    String userInput = ""+r;
    return userInput;
  }

}