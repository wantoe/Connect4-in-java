package connect4Package;

import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.InputStreamReader;
//import java.util.Random;

public class Game{
  //field
  private Board b;
  private BufferedReader input;

  public Game(){
    b = new Board();
  }

  public void playGame(){

    
    //insert player name
    input = new BufferedReader(new InputStreamReader(System.in));
    String playerOneName = getUserInput();
    System.out.println("Welcome " + playerOneName);
    Player player1 = new HumanPlayer(new Token('X'),playerOneName);
    
    Player player2 = new BotPlayer(new Token('O'),"Bot");

    ArrayList<Player> players = new ArrayList<>();
    players.add(player1);
    players.add(player2);
    
    b.printBoard();
    
    int currentPlayer = 0;
    //char player = 'X';
    while(true){
      try{
        // player 1 - X
        Player current = players.get(currentPlayer%2);
        int columnNumInput = 0;
        
        if (current == player1) {
            columnNumInput = Integer.parseInt(player1.getMove());
        }
        if (current == player2) {
            columnNumInput = Integer.parseInt(player2.getMove());
        }
        
        b.placeToken(columnNumInput, current.getToken());
        System.out.println(current.getName() + " has placed a token in column " + columnNumInput);

        b.printBoard();
        
        if (b.checkWin(current.getName(), current.getToken())) {
            System.out.println("WINNN");
            System.exit(0);
        }
        currentPlayer++;
      }
      catch(Exception err){
      }
    }
      
      
      
    }

	
  
  private String getUserInput(){ 
  String toReturn = "";
		try{
      System.out.println("Please enter you player name");
			toReturn = "Player " + input.readLine();
		}
		catch(Exception e){
			System.out.println("Please enter you player name");
    }
		return toReturn;
	}




}