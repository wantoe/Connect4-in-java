package connect4Package;
import java.io.*;

public class HumanPlayer extends Player{
  // field
  private BufferedReader in;
  // inhertied field Token token and String name from superclass?

//constructor 1
  public HumanPlayer(Token token){
    super(token);
    in = new BufferedReader(new InputStreamReader(System.in));
  }

// constructor 2
  public HumanPlayer(Token token, String name){
    super(token,name);
    in = new BufferedReader(new InputStreamReader(System.in));
  }

  public String getMove(){
	System.out.println("Please enter column number 1 to 7");
    String userInputStr = "";
    int columnNum;
    while(true){
      try{
        userInputStr = in.readLine();
        columnNum = Integer.parseInt(userInputStr);
        if(columnNum>=1 && columnNum <=7){
          break;
        }
        else{
          throw new Exception();
        }
      }
      catch(Exception e){
        System.out.println("Please enter column number 1 to 7");
      }
    }
    return userInputStr;
  }

}