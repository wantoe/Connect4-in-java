package connect4Package;

public class Main {

	public static void main(String[] args) {
		System.out.println("Welcome to Connect 4");
		System.out.println("You will play against a Bot");
		System.out.println("You have token \"X\", Bot has token \"O\"");
		System.out.println("To play the game type in the number of the column you want to drop you token in");
		System.out.println("A player wins by connecting 4 counters in a row - vertically, horizontally or diagonally");
		System.out.println("");
		
	    Game g = new Game();
	    g.playGame();
	}

}
