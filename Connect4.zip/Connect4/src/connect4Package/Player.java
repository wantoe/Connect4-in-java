package connect4Package;
import java.io.*;

public abstract class Player{
  //fields
  private Token token;
  private String name;

// constructor1
  public Player(Token token){
    this.token = token;
    name = "player";
  }

// constructor 2
  public Player(Token token, String name){
    this.token = token;
    this.name = name;
  }


  public Token getToken(){
    return token;
  }

  public String getName(){
    return name;
  }

  public abstract String getMove();

}