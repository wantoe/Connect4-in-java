package connect4Package;
public class Token{
	  // field
	  private char t;

	//constructor
	  public Token(char t){
	    this.t = t;
	  }

	// get method
	  public char getToken(){
	    return t;
	  }
	}